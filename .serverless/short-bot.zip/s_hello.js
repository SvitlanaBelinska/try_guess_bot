
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'belinska',
  applicationName: 'mpa-express-serverless',
  appUid: 'wDCK8tL5pJ4tBClRsX',
  orgUid: '2a644f26-3436-48b5-8e74-93e842057f9a',
  deploymentUid: 'c1fccb86-fd50-49a4-89c2-ac88d35ceaf2',
  serviceName: 'short-bot',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'short-bot-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}